import React, { useState, useEffect, useContext } from "react";
import {
  Box,
  Flex,
  Heading,
  Img,
  Select,
  Text,
  Input,
  Button,
} from "@chakra-ui/react";
import axios from "axios";
import { NavBar } from "../Components/NavBar";
import SideBar from "../Components/SideBar";
import MyContext from "../Components/ContextApi/MyContext";
import HomeTable from "../Components/HomeTable";

export const Home = () => {
  const [client, setClient] = useState("");
  const [carrier, setCarrier] = useState("");
  const [billCycle, setBillCycle] = useState("");
  const [file, setFile] = useState(null); // Use null instead of an empty string
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [filter, setFilter] = useState([]);
  const { globalState, setGlobalState } = useContext(MyContext);
  let data = globalState.client;
  let data_carrier = globalState.carrier;

  
   
  
    const [selectedClient, setSelectedClient] = useState('');
  
    const fetchClient = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/client/allclients/");
        setGlobalState({ ...globalState, client: response.data });
      } catch (error) {
        console.log(error);
      }
    };
  
    const fetchCarrier = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/client/allcarrier/");
        setGlobalState({ ...globalState, carrier: response.data });
      } catch (error) {
        console.log(error);
      }
    };
  
    useEffect(() => {
      fetchClient();
      fetchCarrier();
    }, []);
  
    const handleChangeClient = (e) => {
      setSelectedClient(e.target.value);
      setClient(e.target.value)
    };
  
    const filteredCarriers = globalState.carrier.filter(carrier => carrier.client === selectedClient);
  
  console.log("--------------------------------------------------");
  console.log(globalState.client);
  const fetchBills = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:8000/client/processedfiles/");
      setGlobalState((prevState) => ({ ...prevState, bills: response.data }));
    } catch (error) {
      console.error("Error fetching bills:", error);
    }
  };

  const handleFilter = () => {
    axios
      .get(
        `http://localhost:3000/bills?billCycle_gte=${startDate}&billCycle_lte=${endDate}`
      )
      .then((response) => {
        setFilter(response.data);
      })
      .catch((error) => {
        console.error("Error filtering bills:", error);
      });
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]); // Set the selected file
  };

  const handleUpload = async () => {
    if (!file) {
      console.error("No file selected for upload.");
      return;
    }

    const formData = new FormData();
    formData.append('client', client);
    formData.append('carrier', carrier);
    formData.append('billCycle', billCycle);
    formData.append("file", file);

    try {
      await axios.post(`http://127.0.0.1:8000/client/${carrier}/`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      // After successful upload, fetch the updated list of bills
      fetchBills();
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

useEffect(()=>{
  fetchBills()
},[])
  

  return (
    <>
      <NavBar />
      <Box bg="#f2f2f2">
        <Flex>
          <SideBar />
          <Box w="85%" paddingTop="30px" marginLeft="30px">
            <Box>
              <Flex alignItems="center" justifyContent="space-between">
                <Text fontSize="30px" fontWeight="600">
                  Bills
                </Text>
                <Img
                  w="1.5%"
                  src="https://i.ibb.co/dmY8W0k/home.png"
                  marginRight="100px"
                />
              </Flex>
            </Box>
            <br />
            <Box h="13vh" bg="#D6EAF8" w="98%">
              <Flex alignItems="center" justifyContent="space-evenly">
                <Box paddingLeft="10px" paddingTop="5px">
                  <Text textAlign="justify" color="#3259e4">
                    Client *
                  </Text>
                  
                      <select
                        placeholder="Select"
                        bg="white"
                        w="200px"
                        onChange={handleChangeClient}
                      >
                        <option value="">Select Client</option>
                        {globalState.client.map((client, index) => (
                          <option key={index} value={client.name}>
                            {client.name}
                          </option>
                        ))}
                      </select>
                    
                      <label>Carrier *</label>
                      <select
                        bg="white"
                        w="200px"
                        onChange={(e) => setCarrier(e.target.value)}
                      >
                        <option value="">Select Carrier</option>
                        {filteredCarriers.map((carrier, index) => (
                          <option key={index} value={carrier.name}>
                            {carrier.name}
                          </option>
                        ))}
                      </select>
                   
                </Box>

                <Box paddingTop="5px">
                  <Text textAlign="justify" color="#3259e4">
                    Bill Cycle *
                  </Text>
                  <Input
                    type="date"
                    bg="white"
                    placeholder="End Date"
                    value={billCycle}
                    onChange={(e) => setBillCycle(e.target.value)}
                  />
                </Box>

                <Box paddingTop="5px">
                  <Text textAlign="justify" color="#3259e4">
                    Upload Bill Pdf
                  </Text>
                  <Input
                    type="file"
                    bg="white"
                    placeholder="End Date"
                    onChange={handleFileChange}
                  />
                </Box>

                <Box paddingTop="5px">
                  <Text textAlign="justify" color="#3259e4">
                    Upload
                  </Text>
                  <Button
                    onClick={handleUpload}
                    w="200px"
                    bg="#3259e4"
                    color="white"
                  >
                    Upload
                  </Button>
                </Box>
              </Flex>
            </Box>

            <Box h="10vh" w="98%" bg="white">
              <Flex alignItems="center" gap="10px">
                <Box paddingTop="13px" paddingLeft="20px">
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </Box>
                <Box paddingTop="13px">
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </Box>
                <Box paddingTop="13px">
                  <Button onClick={handleFilter} bg="#3259e4" color="white">
                    Filter Listing
                  </Button>
                </Box>
              </Flex>
            </Box>
            <HomeTable />
          </Box>
        </Flex>
      </Box>
    </>
  );
};
