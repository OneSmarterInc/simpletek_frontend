import React from 'react'

import Login from './Login'

import { Routes,Route } from 'react-router-dom'
import { Home } from './Home';
import { ArchieveList } from './ArchieveList';
import { Clients } from './Clients';
import { Carriers } from './Carriers';
import { ChangePassword } from './ChangePassword';
import DeletedList from './DeletedList';

export const MainRoutes = () => {
  return <Routes>
    <Route path='/' element={<Home />}/>
     <Route path='/login' element={<Login/>} />
    <Route path='/clients' element={<Clients />}/>
    <Route path='/carriers' element={<Carriers />}/>
    <Route path='/archievelist' element={<ArchieveList />}/>
    <Route path='/changepassword' element={<ChangePassword />}/>
    <Route path='/deletedlist' element={<DeletedList/>} />
    <Route path='*' element={<h1>No Page Found</h1>} />
    </Routes>
}
