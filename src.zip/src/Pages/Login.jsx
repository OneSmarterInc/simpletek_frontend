import { Box, Flex, Image, Input, FormLabel, Text, Button, InputRightElement, chakra, InputGroup, InputLeftElement } from '@chakra-ui/react'
import React, { useContext, useState } from 'react'
import loginImage  from "../Images/login-bg.jpg";
import { FaUserAlt, FaLock } from "react-icons/fa";
import MyContext from '../Components/ContextApi/MyContext';
import axios from 'axios';


const CFaUserAlt = chakra(FaUserAlt);
const CFaLock = chakra(FaLock);


const Login = () => {

  const {globalState, setGlobalState} = useContext(MyContext);


    const [showPassword, setShowPassword] = useState(false);

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");



  const handleShowClick = () => setShowPassword(!showPassword);

  const handleLogin = async()=>{
    let loginData = {
      email,
      password
    }
      try {
        await axios.post("",loginData)
      } catch (error) {
        console.log(error);
      }
  }
  return (
    <Flex>
        <Box bgColor={"gray.100"} border={"0px solid red"} height={"100vh"} w={"100%"}>
            <Box w={"26%"} m={"auto"} mt={10} border={"0px solid black"}>
                <Image w={"100%"} src='http://157.245.111.62:8080/simpletek/images/logo-blue.svg' />
            </Box>
            <Box borderRadius={"10px"} border={"1px solid #D3D3D3"} w={"60%"} m={"auto"} mt={"100px"} bgColor={"white"} p={6}>
            <FormLabel fontSize={27}>Admin Login</FormLabel>
                <FormLabel mt={4} fontSize={15} color={"grey"}>Registered Email*</FormLabel>
                <InputGroup>
                <Input placeholder='Ex: graham@yesenia.net' value={email} onChange={(e)=>setEmail(e.target.value)} />
                <InputLeftElement 
                pointerEvents="none"
                children={<CFaUserAlt color="gray.300" />} />
                </InputGroup>
               
                <FormLabel mt={3} fontSize={15} color={"grey"}>Password*</FormLabel>
               <InputGroup>
               <InputLeftElement 
                pointerEvents="none"
                children={<CFaLock color="gray.300" />} />
                <Input placeholder='******' type={showPassword ? "text" : "password"} value={password} onChange={(e)=>setPassword(e.target.value)}/>
                <InputRightElement width="4.5rem">
                    <Button h="1.75rem" size="sm" onClick={handleShowClick}>
                      {showPassword ? "Hide" : "Show"}
                    </Button>
                  </InputRightElement>
               </InputGroup>
                <Flex mt={6} alignItems={"center"} justifyContent={"space-between"} border={"0px solid red"}>
                <Button bgColor={"#3259E4"} color={"white"} onClick={handleLogin} >Login</Button>
                <Text>Forgot Password?</Text>
                </Flex>
                
            </Box>
        </Box>
        <Box backgroundImage={loginImage} backgroundSize={"cover"} backgroundRepeat={"no-repeat"} border={"0px solid red"} height={"100vh"} w={"100%"}>
            {/* <Image  w={"100%"} src={loginImage} /> */}
        </Box>
   </Flex>
  )
}

export default Login