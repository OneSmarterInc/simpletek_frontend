import {
  Alert,
  Box,
  Button,
  Flex,
  Table,
  TableCaption,
  TableContainer,
  Tbody,
  Td,
  Tfoot,
  Th,
  Thead,
  Tr,
} from "@chakra-ui/react";
import { DeleteIcon, DownloadIcon, InfoIcon } from "@chakra-ui/icons";
import { AlertIcon } from "@chakra-ui/react";
import { AiOutlineCheckCircle } from "react-icons/ai";

import React, { useContext, useEffect } from "react";
import axios from "axios";
import MyContext from "./ContextApi/MyContext";

const HomeTable = () => {

  const { globalState, setGlobalState} = useContext(MyContext);
  let data = globalState.bills;

  const fetchBills = async()=>{
    try {
       let data =  await axios.get("http://127.0.0.1:8000/client/processedfiles/");
      console.log(data.data);
      

      // console.log(data.data);
       setGlobalState((globalState)=>({...globalState, bills:data.data}))
    } catch (error) {
      console.log(error);
    }
  }

  const handleDelete = async (el)=>{
      try {
        await axios.post(`http://localhost:3000/deleted`,el)
        .then((res)=>{
          axios.delete(`http://localhost:3000/bills/${el.id}`)
         fetchBills();
        })
        .catch((err)=>{
          console.log(err);
        })
  
      } catch (error) {
        console.log(error);
      }
  }

  const handleDownload = (url)=>{
      let link = document.createElement("a");
      link.href = url;
      link.download = url;

      document.body.appendChild(link);
      link.click();

     document.body.removeChild(link);
  }

  useEffect(()=>{
    fetchBills();
  },[])
  
  return (
    <TableContainer mt={6} pr={6}>
      <Table variant="striped">
        <Thead backgroundColor={"#3259E4"}>
          <Tr border={"0px solid red"}>
            <Th color={"white"}>#</Th>
            <Th color={"white"}>Company</Th>
            <Th color={"white"}>Created</Th>
            <Th color={"white"}>pdf</Th>
            <Th color={"white"}>Excel</Th>
            <Th color={"white"}>Excel_Detail</Th>
            <Th color={"white"}>Analysis</Th>
            <Th color={"white"}>Action</Th>
          </Tr>
        </Thead>
        <Tbody>
          {data.length > 0 ? data.map((el,i)=>{
            return (
        <Tr key={el.id}>
            <Td>{i+1}</Td>

            

            <Td>{el.client_name}</Td>

            <Td>{el.billCycle_date}</Td>
            {/* <Td>
              <AiOutlineCheckCircle color="green" size={"2em"} />
            </Td> */}
             <Td>
             <a href={`http://127.0.0.1:8000/${el.original_pdf}`} download={el.original_pdf}>
  Download
</a>
              <Button
                size={"sm"}
                borderRadius={"2rem"}
                backgroundColor={"#97D0BB"}
                color={"#416D5B"}
                leftIcon={<DownloadIcon />}
                onClick={()=>handleDownload(el.original_pdf)}
              >
                Download
              </Button>
            </Td>
            <Td>
            <a href={`http://127.0.0.1:8000/${el.excel_summary}`} download={el.excel_summary}>Download</a>
              <Button
                size={"sm"}
                borderRadius={"2rem"}
                backgroundColor={"#97D0BB"}
                color={"#416D5B"}
                leftIcon={<DownloadIcon />}
                onClick={()=>handleDownload(el.excel_summary)}
              >
              
                Download
              </Button>
            </Td>
            <Td>

                <a href={`http://127.0.0.1:8000/${el.excel_details}`} download={el.excel_details}>Download</a>

              <Button
                size={"sm"}
                borderRadius={"2rem"}
                backgroundColor={"#97D0BB"}
                color={"#416D5B"}
                leftIcon={<DownloadIcon />}
                onClick={()=>handleDownload(el.excel_details)}
                
              >
                Download
              </Button>
            </Td>
            <Td>
              <Button
                size={"sm"}
                borderRadius={"2rem"}
                backgroundColor={"#DCBBBC"}
                color={"#CA595E"}
                leftIcon={<DownloadIcon />}
              >
               Start
              </Button>
            </Td>
            <Td>
              {/* <InfoIcon cursor={"pointer"} color={"#3259E4"} /> */}
              <DeleteIcon onClick={()=>handleDelete(el)} cursor={"pointer"} ml={4} color={"red"} />
            </Td>
          </Tr>
            )
          }) : <TableCaption>No Data Found</TableCaption>}
          

         
        </Tbody>
      </Table>
    </TableContainer>
  );
};

export default HomeTable;
