import React from 'react';
import { Box,Flex,Heading,Img,Select,Text,Input, Button } from '@chakra-ui/react';
import { Link } from 'react-router-dom';


const SideBar = () => {
  return (
    <Box w={'15vw'} minH={'88vh'} bg={'#cccccc'} textAlign={'justify'} paddingTop={'30px'} paddingLeft={'20px'} >
        
       <Box>
       <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/xD7T0jW/document.png'/>
        <Link to={'/'}>
        <Text color={'#3259e4'}>Bills</Text>
        </Link>
        </Flex>
       </Box>
        <br />
        <Box>
        <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/ZSMSK2d/user-3.png'/>
        <Link to={'/clients'}>
        <Text color={'#3259e4'}>Clients</Text>
        </Link>
        </Flex>
        </Box>
        <br />
        <Box>
        <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/Wxb4XYV/signal.png'/>
        <Link to={'/carriers'}>
        <Text color={'#3259e4'}>Carriers</Text>
        </Link>
        </Flex>
        </Box>
        <br />
        <Box>
        <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/4S5CSvn/archive.png'/>
        <Link to={'/archievelist'}>
        <Text color={'#3259e4'}>Archive List</Text>
        </Link>
        </Flex>
        </Box>
        <br />
        <Box>
        <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/4S5CSvn/archive.png'/>
        <Link to={'/deletedlist'}>
        <Text color={'#3259e4'}>Deleted List</Text>
        </Link>
        </Flex>
        </Box>
        <br />
        <Box>
        <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/BynCnr6/padlock-unlock.png'/>
        <Link to={'/changepassword'}>
        <Text color={'#3259e4'}>Change Password</Text>
        </Link>
        </Flex>
        </Box>
        <br />
        <Box>
        <Flex alignItems={'center'} gap={'6px'}>
        <Img w={'8%'} src='https://i.ibb.co/ZSMSK2d/user-3.png'/>
        <Text color={'#3259e4'}>Log Out</Text>
        </Flex>
        </Box>
    
    </Box>
  )
}

export default SideBar