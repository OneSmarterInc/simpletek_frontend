import { Avatar, Box, Flex, Img,Text } from '@chakra-ui/react'
import React from 'react'
import { Link } from 'react-router-dom'

export const NavBar = () => {
  return <Box>
    <Box pt={1} h={'11vh'} bg={'#3259e4'}>
        <Flex alignItems={'center'} justifyContent={'space-between'}>
            <Box marginLeft={'40px'} w={"10%"} border={"0px solid black"}>
                <Link to={'/'}><Img src='http://157.245.111.62:8080/simpletek/images/logo.svg' w={'100%'} /></Link>
            </Box>
        <Box w={'auto'} alignItems={'center'}  marginRight={'30px'}>
            <Flex justifyContent={'space-between'} alignItems={"center"} gap={'15px'}>
                <Avatar src='http://157.245.111.62:8080/simpletek/images/avatar.png'/>
                <Text color={'white'}>deep@simpletek.com</Text>
            </Flex>
        </Box>
        </Flex>
    </Box>
  </Box>
}
