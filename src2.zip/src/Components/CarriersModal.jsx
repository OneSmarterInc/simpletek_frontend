import { Button, FormLabel, Input, InputGroup, Modal, ModalBody, ModalCloseButton, ModalContent, ModalFooter, ModalHeader, ModalOverlay, Text, useDisclosure } from "@chakra-ui/react";
import axios from "axios";
import { useContext, useState } from "react";
import MyContext from "./ContextApi/MyContext";

function CarriersModal() {
    const { isOpen, onOpen, onClose } = useDisclosure();

    const {globalState, setGlobalState, api_domain} = useContext(MyContext);
    const [name,setName] = useState("");

    const fetchCarrier = async()=>{
      try {
        let data = await axios.get(`${api_domain}allcarrier/`);
        //  console.log(data.data);     
        setGlobalState({...globalState, carrier:data.data})  
        
      } catch (error) {
        console.log(error);
      }
    }
   

 

    const postCarrier = async()=>{
      let carrierData = {
        name
      }
      // console.log(clientData);
      try {
        await axios.post(`${api_domain}allcarrier/`,carrierData)
        .then(()=>{
          fetchCarrier();
        })
        setName("");
        onClose();
        
      } catch (error) {
        console.log(error);
      }
    }

  
    return (
      <>
        <Button bg={'#339900'} color={'white'} _hover={{'bg':'#194c00'}} borderRadius={'50px'} marginTop={'10px'} size={'sm'} onClick={onOpen} > + Add Carrier</Button>
  
  <Modal blockScrollOnMount={false} isOpen={isOpen} onClose={onClose} >
    <ModalOverlay  />
    <ModalContent bgColor={"#cccccc"}>
      <ModalHeader>Add Carrier</ModalHeader>
      <ModalCloseButton />
      <ModalBody>
        <InputGroup >
        <Input bgColor={"white"} placeholder="Enter Carrier Name"  value={name} onChange={(e)=>setName(e.target.value)}/>
        </InputGroup>
      </ModalBody>

      <ModalFooter>
        <Button color={"white"} bgColor='#3259E4' onClick={postCarrier}>
          Add Carrier
        </Button>
      </ModalFooter>
    </ModalContent>
  </Modal>
      </>
    )
  }

  export default CarriersModal;